
<!-- README.md is generated from README.Rmd. Please edit that file -->

# renvvv

<!-- badges: start -->

[![R-CMD-check](https://github.com/MiguelRodo/renvvv/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/MiguelRodo/renvvv/actions/workflows/R-CMD-check.yaml)
[![Codecov test
coverage](https://codecov.io/gh/MiguelRodo/renvvv/graph/badge.svg)](https://app.codecov.io/gh/MiguelRodo/renvvv)
<!-- badges: end -->

renvvv provides utility functions for managing R project dependencies
using [`renv`](https://rstudio.github.io/renv/), with specialized tools
for HPC environments.

## Installation

You can install the development version of renvvv from
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("MiguelRodo/renvvv")
```

## Usage

### renv Package Management

The primary functionality of this package is robust `renv` restoration
and management:

``` r
library(renvvv)

# Restore packages from renv lockfile (recommended)
renvvv_restore()

# Update packages to latest versions
renvvv_update()

# Restore then update all packages
renvvv_restore_and_update()

# Add packages to _dependencies.R and install them
renvvv_dep_add(c("dplyr", "ggplot2"))
```

The `renvvv_restore()` function handles CRAN, Bioconductor, and GitHub
packages with automatic fallback for packages that fail to restore.

### HPC Setup

Configure your project for HPC (SLURM) environments:

``` r
# Set up .Rprofile to use scratch directory for renv on HPC
renvvv_hpc_renv_setup()

# Configure renv to use correct repositories across different OSs
renvvv_renv_repos_setup()
```

## License

This package is licensed under the MIT License.
