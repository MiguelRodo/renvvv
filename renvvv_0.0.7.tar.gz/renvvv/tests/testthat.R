# This file is part of the standard {testthat} test machinery.
# For more information on this file and testthat see:
# https://testthat.r-lib.org

library(testthat)
library(renvvv)

test_check("renvvv")
