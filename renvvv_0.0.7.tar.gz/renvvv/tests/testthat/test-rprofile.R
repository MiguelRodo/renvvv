test_that("renvvv_hpc_renv_setup function exists", {
  expect_true(is.function(renvvv_hpc_renv_setup))
})

test_that("renvvv_renv_repos_setup function exists", {
  expect_true(is.function(renvvv_renv_repos_setup))
})
